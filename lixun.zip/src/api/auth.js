import {
    subCode,
    getCodeUrl
} from '@/api/tool.js'
import { Toast } from "mint-ui";
var auth = (status, message = null) => {
    // let url = "http://192.168.137.1:8080";
    // let url = "http://192.168.1.141:8080";
    // let url = "http://192.168.1.113:8080";
    // let url = "http://chenjianguang.com/lixun";
    let url = "http://jwwo.szer.me/lx/index.html";
    // let url = window.location.href;

    switch (status) {
        case 40102:
            Toast({
                message: "登录超时,重新登录中",
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
            });
            setTimeout(() => {
                window.location.href = getCodeUrl(url, "wx0c6e2f0a288033bc", 2);
            }, 1000);
            break;
        case 40005:
            Toast({
                message: "登录失败,重新登录中",
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
            });
            // sessionStorage.setItem("path", window.location.hash.substr(1));
            setTimeout(() => {
                window.location.href = getCodeUrl(url, "wx0c6e2f0a288033bc", 2);
            }, 1000);
            break;
        case 40402:
            alert("暂无资源");
        case 40302:
            message ? Toast({
                message: message,
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
            }) : null;
        case 40003:
            message ? Toast({
                message: message,
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
            }) : null;
        default:
            message ? Toast({
                message: message,
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
            }) : null;
            break;
    }
};
export default auth;