<template>
  <div class="release-container">
    <div class="release">
    <i class="iconfont icon-back" @click="goback"></i>
    <label for="title" class="title-label">标题:</label>
    <input type="text" id="title" v-model="title" placeholder="10字以内">
    <span class="iconfont icon-biaoqian" @click="showSelect=!showSelect">选择标签</span>
   <transition name="select-fade" mode="out-in"> <selects v-show="showSelect" class="white-select-detail" @selectSure="selectSure($event)"></selects></transition>
    <textarea name="describe" id="describe" cols="41" rows="10" placeholder="100字以内的详情描述" v-model="content"></textarea>
    <div class="message">
        <label for="weixin">微信:</label><input type="text" id="weixin" v-model="wechat" placeholder="20字以内"><br>
        <label for="phone">手机:</label><input type="text" id="phone" v-model="phone" placeholder="11位号码">
    <template v-for="(item,index) in selectType">
    <myCheckbox :key="item.id" :isSelect="item.isSelect" @click.native="changeType(index)">{{item.name}}</myCheckbox>
    </template>
    </div>
    <label class="iconfont icon-add" for="file"></label>
    <input type="file" id="file" @change="showImage()" accept="image/*">
    <img :src="fileImage" alt="上传图" class="file-image" v-show="fileImage!=''" @click="popupVisible=true">
    <mt-popup
    v-model="popupVisible" popup-transition="popup-fade" class="mint-popup-1">
     <img :src="fileImage" alt="原图">
    </mt-popup>
    </div>
    <div class="Triangle"></div>
    <!-- <img src="/static/images/sub.png" alt="点击提交" class="subButton" @click="subMessage"> -->
    <button class="edit-button" @click="edit">修改</button> 
    <button class="delete-button" @click="del">删除</button>
    <button class="solve-button" @click="solve">已解决</button> 
  </div>
</template>
<script>
import lrz from "../../../node_modules/lrz/dist/lrz.all.bundle";
import myCheckbox from "@/components/comm/my-checkbox";
import selects from "@/components/comm/selects";
import ajax from "api/ajax";
import axios from "axios";
import { Toast } from "mint-ui";
import { MessageBox } from "mint-ui";
export default {
  mounted() {
    document.body.scrollTop = 0;
    document.getElementById("footer-nav").style.display = "none";
    let id = this.$route.query.id,
      state = this.$route.query.state,
      lixun = sessionStorage.getItem("lixun");
    this.$ajax({
      method: "get",
      url: "/info/" + id
    })
      .then(res => {
        console.log("要修改的原来的信息", res);
        this.title = res.data.data.info.title;
        this.content = res.data.data.info.content;
        this.phone = res.data.data.info.phone;
        this.wechat = res.data.data.info.wechat;
      })
      .catch(err => {
        console.log(err);
      });
  },
  beforeDestroy() {
    document.getElementById("footer-nav").style.display = "block";
  },
  data() {
    return {
      files: [],
      fileImage: "",
      popupVisible: false,
      selected: "",
      selectType: [
        { type: 1, name: "寻物", isSelect: false, id: 1 },
        { type: 2, name: "招领", isSelect: false, id: 2 }
      ],
      showSelect: false,
      title: "",
      phone: "",
      content: "",
      name: "",
      wechat: "",
      upImage: [],
      type: null,
      whattag: "",
      wheretag: ""
    };
  },
  methods: {
    goback() {
      //  document.getElementById("footer-nav").style.display = "block";
      this.$router.go(-1);
    },
    showImage() {
      let file = document.getElementById("file").files[0];
      let _this = this;
      lrz(file)
        .then(function(rst) {
          Toast({
            message: "添加成功",
            iconClass: "iconfont icon-success1",
            duration: 1000
          });
          // 处理成功会执行
          console.log(rst);
          _this.fileImage = rst.base64;
        })
        .catch(function(err) {
          // 处理失败会执行
          Toast({
            message: "添加失败",
            iconClass: "iconfont icon-fail"
          });
        })
        .always(function() {
          // 不管是成功失败，都会执行
          console.log("调用上传图片");
        });
    },
    changeType(index) {
      this.selectType.forEach((element, num) => {
        index == num ? (element.isSelect = true) : (element.isSelect = false);
        index == num ? (this.type = index + 1) : null;
      });
    },
    selectSure(e) {
      this.showSelect = false;
      if (e[0][0].wheretag && e[1][0].whattag) {
        this.wheretag = e[0][0].wheretag;
        this.whattag = e[1][0].whattag;
      } else if (e[0][0].wheretag) {
        this.wheretag = e[0][0].wheretag;
      } else if (e[1][0].whattag) {
        this.whattag = e[1][0].whattag;
      }
      console.log(e);
    },
    edit() {
      let lixun = sessionStorage.getItem("lixun");
      let id = this.$route.query.id;
      new Promise((resolve, reject) => {
        if (!this.title || this.title.length >= 10) {
          this.title ? reject("标题字数应该小于10") : reject("要填写标题哦");
        } else if (!this.content || this.content.length >= 200) {
          this.content
            ? reject("内容的字数应该小于200")
            : reject("要填写内容哦");
        } else if (!this.wechat || this.wechat.length >= 20) {
          this.wechat ? reject("微信字数应该小于20") : reject("要填写微信哦");
        } else if (!this.phone || this.phone.length != 11) {
          this.phone ? reject("手机格式不对") : reject("要填写手机哦");
        } else if (!this.whattag || !this.wheretag) {
          !this.wheretag ? reject("要选择地点标签哦") : "";
          !this.whattag ? reject("要选择物品标签哦") : "";
        } else if (!this.type) {
          reject("要选择寻物或者招领哦");
        } else {
          MessageBox.confirm("确定修改发布？").then(
            success => {
              resolve("修改成功，已经更新发布");
            },
            cancel => {
              reject("你取消了修改");
            }
          );
        }
      }).then(
        tip => {
          this.$ajax({
            method: "post",
            url: "/info/" + id + "/update",
            data: {
              title: this.title,
              content: this.content,
              phone: this.phone,
              wechat: this.wechat,
              type: this.type,
              wheretag: this.wheretag,
              whattag: this.whattag,
              picurl: this.fileImage
            }
          })
            .then(res => {
              console.log("1111", res.data.data.list);
              Toast({
                message: tip,
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 1000
              });
              setTimeout(() => {
                this.$router.replace({ path: "/history/noSolve" });
              }, 1000);
            })
            .catch(err => {
              // console.log(err);
            });
        },
        tip => {
          Toast({
            message: tip,
            iconClass: "iconfont icon-xiaolianchenggong",
            duration: 800
          });
        }
      );
    },
    del() {
      console.log("del");
      MessageBox.confirm("确定是否删除？").then(
        success => {
          let id = this.$route.query.id,
            lixun = sessionStorage.getItem("lixun");
          this.$ajax({
            method: "delete",
            url: "/info/" + id 
          })
            .then(res => {
              setTimeout(() => {
                this.$router.replace({ path: "/history/noSolve" });
              }, 1000);
              Toast({
                message: "删除成功，进入历史页面",
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
              });
              console.log(res);
            })
            .catch(err => {
              console.log(err);
            });
        },
        cancel => {
          Toast({
            message: "你取消了删除",
            iconClass: "iconfont icon-xiaolianchenggong",
            duration: 800
          });
        }
      );
    },
    solve() {
      console.log("solve");
      MessageBox.confirm("确定是否已经解决？").then(
        success => {
          let id = this.$route.query.id,
            lixun = sessionStorage.getItem("lixun");
          this.$ajax({
            method: "post",
            url: "/info/" + id + "/over"
          })
            .then(res => {
              setTimeout(() => {
                this.$router.replace({ path: "/history/hasSolve" });
              }, 1000);
              Toast({
                message: "已经解决，进入历史已解决页面",
                iconClass: "iconfont icon-xiaolianchenggong",
                duration: 800
              });
              console.log(res);
            })
            .catch(err => {
              console.log(err);
            });
        },
        cancel => {
          Toast({
            message: "你取消了删除",
            iconClass: "iconfont icon-xiaolianchenggong",
            duration: 800
          });
        }
      );
    }
  },
  components: {
    myCheckbox,
    selects,
    Toast,
    MessageBox
  }
};
</script>
<style lang="scss" scoped>
.release-container {
  @import "../../assets/variable";
  @import "../../assets/mixin";
  background-color: #ddd;
  width: 100%;
  height: 1200px;
  overflow: hidden;
  .edit-button,
  .delete-button,
  .solve-button {
    font-size: 30px;
    width: 200px;
    height: 80px;
    border-radius: 30px;
    outline: none;
    background-color: $lizhiColor;
    color: #ffffff;
    border: none;
    padding: 0;
    margin-left: 30px;
  }
  #file {
    display: none;
  }
  .file-image {
    position: relative;
    left: 100px;
    top: 85px;
    width: 100px;
    height: 100px;
  }
  .mint-popup-1 {
    height: 600px;
    img {
      width: 600px;
      height: 600px;
      text-align: center;
      margin: 0;
      padding: 0;
      border-radius: 10px;
    }
  }
  .release {
    width: 700px;
    position: relative;
    background-color: #fff;
    height: 800px;
    padding-top: 10px;
    margin: 30px auto;
    border-radius: 16px;
    box-shadow: 0 0 15px #bbb;
    overflow: hidden;
    input {
      border-radius: 0;
    }
    .icon-back {
      font-size: 50px;
      color: $lizhiColor;
      position: relative;
      left: 10px;
      top: 5px;
    }
    .title-label {
      color: $lizhiColor;
      font-size: 40px;
      font-weight: bolder;
      margin-left: 20px;
    }
    #title {
      border: none;
      border-bottom: 2px solid $lizhiColor;
      outline: none;
      width: 300px;
      font-size: 30px;
      height: 30px;
      line-height: 30px;
    }
    .icon-biaoqian {
      color: $lizhiColor;
      font-size: 30px;
      line-height: 30px;
      margin-left: 20px;
    }
    .white-select-detail {
      background-color: #ffffff;
      position: absolute;
      z-index: 3;
    }
    #describe {
      margin: 20px auto;
      margin-left: 60px;
      outline: none;
      border: none;
      font-size: 26px;
      overflow: hidden;
      height: 45%;
    }
    .message {
      width: 100%;
      margin-left: 58px;
      input {
        outline: none;
        border: none;
        border-bottom: 2px solid $lizhiColor;
        margin: 5px 5px;
        width: 280px;
      }
      label {
        color: $lizhiColor;
        margin: 0 10px;
        position: relative;
        top: 6px;
      }
    }
    .icon-add {
      color: $lizhiColor;
      font-size: 60px;
      position: relative;
      left: 10%;
      top: 60px;
      border: 1px solid $lizhiColor;
      padding: 20px;
    }

    @include change-placeholder($lizhiColor,25px);
  }
  .Triangle {
    width: 0;
    height: 0;
    border: 40px solid #ffffff;
    border-color: #fff transparent transparent transparent;
    position: relative;
    margin: 0 auto;
    margin-top: -40px;
  }
  .subButton {
    width: 180px;
    height: 180px;
    display: block;
    margin: 0 auto 0;
    margin-top: -40px;
  }
}
</style>


