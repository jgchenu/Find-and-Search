<template>
  <div class="edit-button iconfont icon-icon10">
      
  </div>
</template>
<script>
export default {};
</script>
<style lang="scss" scoped>
@import "../../assets/variable";
.edit-button {
  z-index: 111111;
  position: fixed;
  bottom: 200px;
  right: 50px;
  height: 100px;
  width: 100px;
  border-radius: 50%;
  background-color: $lizhiColor;
  text-align: center;
  color: #ffffff;
  line-height: 100px;
  font-size: 40px;
  cursor: pointer;
  box-shadow: 0 0 14px #bbbbbb;
}
</style>

